public class _03_PrintHometown {

	public static void main(String[] args) {
		System.out.println("My hometwon is Pernik.");

	}

}
