#!/bin/bash
java -jar Executable.jar
